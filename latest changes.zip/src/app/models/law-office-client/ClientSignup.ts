export class ClientSignup {
  AdminID: number;
  UserName: string;
  Password: string;
  FirstName: string;
  LastName: string;
  Email: string;
  Mobile: string;
  OrganisationName: string;
}
