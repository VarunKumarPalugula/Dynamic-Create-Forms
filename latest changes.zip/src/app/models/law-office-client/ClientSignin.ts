export class ClientSignin {
  UserName: string;
  Password: string;
  Scope: string;
  Email: string;
}
