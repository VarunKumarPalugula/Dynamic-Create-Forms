export class AdminSignup {
  AdminID: number;
  UserName: string;
  Password: string;
  FirstName: string;
  LastName: string;
  FullName: string;
  Email: string;
  Mobile: string;
  OrganisationName: string;
  OrgId: string;
  // Scope: string = 'ADMIN';
  // username: string;
  // password: string;
  // grant_type: string = 'password';
}
