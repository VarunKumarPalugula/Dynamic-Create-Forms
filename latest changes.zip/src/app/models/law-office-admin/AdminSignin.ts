export class AdminSignin {
  UserName: string;
  Password: string;
  Scope: string;
  Email: string;
}
