export class TokenParams {
  access_token: string;
  token_type: string;
  // expires_in:string;
}
