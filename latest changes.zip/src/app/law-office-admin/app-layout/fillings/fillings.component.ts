import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fillings',
  template: `<router-outlet></router-outlet>`,
})
export class FillingsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
