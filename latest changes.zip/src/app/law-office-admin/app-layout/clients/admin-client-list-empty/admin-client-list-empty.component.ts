import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-client-list-empty',
  templateUrl: './admin-client-list-empty.component.html',
  styleUrls: ['./admin-client-list-empty.component.scss'],
})
export class AdminClientListEmptyComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
