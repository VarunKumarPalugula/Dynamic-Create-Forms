import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-multipleclient-invite',
  templateUrl: './admin-multipleclient-invite.component.html',
  styleUrls: ['./admin-multipleclient-invite.component.scss'],
})
export class AdminMultipleclientInviteComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
