import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-client-import-match-copy',
  templateUrl: './admin-client-import-match-copy.component.html',
  styleUrls: ['./admin-client-import-match-copy.component.scss'],
})
export class AdminClientImportMatchCopyComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
