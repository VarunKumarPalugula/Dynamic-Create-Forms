import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-law-office-admin',
  template: `<router-outlet></router-outlet>`,
})
export class LawOfficeAdminComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
