import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-law-office-client',
  template: `<router-outlet></router-outlet>`,
})
export class LawOfficeClientComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
