import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-invite-confirm',
  templateUrl: './team-invite-confirm.component.html',
  styleUrls: ['./team-invite-confirm.component.scss'],
})
export class TeamInviteConfirmComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
