import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timelines',
  templateUrl: './timelines.component.html',
  styleUrls: ['./timelines.component.scss'],
})
export class TimelinesComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
