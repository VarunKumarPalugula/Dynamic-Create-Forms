import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'beneficiars-tasks',
  templateUrl: './beneficiars-tasks.component.html',
  styleUrls: ['./beneficiars-tasks.component.scss'],
})
export class BeneficiarsTasksComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
