import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-country-state-city',
  templateUrl: './country-state-city.component.html',
  styleUrls: ['./country-state-city.component.css']
})
export class CountryStateCityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
