import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lawoffice-applicant',
  template: `<router-outlet></router-outlet>`,
})
export class LawofficeApplicantComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
