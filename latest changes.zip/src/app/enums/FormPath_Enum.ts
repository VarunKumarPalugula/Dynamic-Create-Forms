export enum FormPath {
    G28 = '../../../../../assets/forms/g28_in_one_page(new).pdf'
  }