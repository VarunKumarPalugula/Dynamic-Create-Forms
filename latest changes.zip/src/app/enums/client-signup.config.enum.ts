export enum clientSignupEnum {
  CLIENTROLETYPE = '1',
  APPLICANTROLETYPE = '2',
  SPONSORTYPE = '3',
  CLIENTTITTLE = 'Client Organization',
  APPLICANTTITTLE = 'Applicant',
  SPONSORTITTLE = 'Sponsor',
  APPLICANTROLE = 'APPLICANT',
  CLIENTROLE = 'CLIENT',
}
