export const UrlConfig = {
  ADMING28URL : '/admin/fillings/g28',
  DOMIN : 'http://54.227.82.119/',
  ENVDOMAIN : 'http://lawoffices3.s3-website-us-east-1.amazonaws.com'
}